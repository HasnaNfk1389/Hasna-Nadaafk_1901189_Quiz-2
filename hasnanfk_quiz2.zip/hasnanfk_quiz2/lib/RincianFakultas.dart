import 'package:flutter/widgets.dart';
import 'package:flutter/material.dart';

class RincianFakultas extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('FPMIPA'),
      ),
      body: Center(
        child: Text("Fakultas ini terdiri dari 7 departemen, diantaranya : Ilmu Komputer, Pendidikan Ilmu Komputer, IPSE, Pendidikan Fisika, Fisika murni, Biologi, Matematika"),
      ),
    );
  }
}
